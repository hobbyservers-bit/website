import { Router } from 'express';
import { upstream } from '../upstream.js';
import { normalizeServer } from '../normalize.js';
import { MOCK_SERVERS, MOCK_TAGS } from '../mock.js';

const router = Router();

// GET /api/servers/popular
// Top 8 online servers by rating — used by the homepage carousel
router.get('/popular', async (req, res) => {
  try {
    const data    = await upstream('/api/v1/servers?public=1&status=ONLINE&limit=50');
    const servers = (data.servers ?? [])
      .map(normalizeServer)
      .sort((a, b) => b.rating_positive - a.rating_positive)
      .slice(0, 8);
    res.json({ success: true, data: servers });
  } catch (err) {
    console.warn('[servers/popular] fallback:', err.message);
    res.json({ success: true, data: MOCK_SERVERS.slice(0, 8).map(normalizeServer), mock: true });
  }
});

// GET /api/servers
// All public servers — supports ?tag=, ?sort=popular|newest, ?page=, ?limit=
router.get('/', async (req, res) => {
  const { tag, sort = 'popular', page = '1', limit = '12' } = req.query;
  const pageNum  = Math.max(1, parseInt(page)  || 1);
  const limitNum = Math.min(50, Math.max(1, parseInt(limit) || 12));

  try {
    const params = new URLSearchParams({ public: '1', limit: '200' });
    if (tag) params.set('tag', tag);

    const data    = await upstream(`/api/v1/servers?${params}`);
    let servers   = (data.servers ?? []).map(normalizeServer);

    servers.sort(sort === 'newest'
      ? (a, b) => new Date(b.created_at ?? 0) - new Date(a.created_at ?? 0)
      : (a, b) => b.rating_positive - a.rating_positive
    );

    const total     = servers.length;
    const paginated = servers.slice((pageNum - 1) * limitNum, pageNum * limitNum);
    res.json({ success: true, data: paginated, total, page: pageNum, limit: limitNum });
  } catch (err) {
    console.warn('[servers] fallback:', err.message);
    const filtered  = tag ? MOCK_SERVERS.filter(s => s.tag_ids.includes(tag)) : MOCK_SERVERS;
    const paginated = filtered.slice((pageNum - 1) * limitNum, pageNum * limitNum);
    res.json({ success: true, data: paginated.map(normalizeServer), total: filtered.length, page: pageNum, limit: limitNum, mock: true });
  }
});

// GET /api/servers/tags
// All unique tags derived from public servers
router.get('/tags', async (req, res) => {
  try {
    const data   = await upstream('/api/v1/servers?public=1&limit=200');
    const tagSet = new Set();
    (data.servers ?? []).forEach(s => (s.tag_ids ?? []).forEach(t => tagSet.add(t)));
    const tags = [...tagSet].map((name, i) => {
      const mock = MOCK_TAGS.find(t => t.name === name);
      return mock ?? { id: String(i + 1), name, display_name: name, emoji: '🏷️' };
    });
    res.json({ success: true, data: tags });
  } catch (err) {
    console.warn('[servers/tags] fallback:', err.message);
    res.json({ success: true, data: MOCK_TAGS, mock: true });
  }
});

export default router;
